//
//  StateView.swift
//  RestOwl
//
//  Sleep overview tab — shows debt, weekly bars, quality score,
//  circadian rhythm and a tip banner. All data flows from AppStore
//  and HealthKitManager; no dismiss button needed (it is a tab).
//

import SwiftUI

struct StateView: View {
    @EnvironmentObject var hk: HealthKitManager
    @EnvironmentObject var store: AppStore

    private var df: DateFormatter {
        let f = DateFormatter()
        f.dateFormat = "HH:mm"
        return f
    }

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 18) {

                    // ── Sleep Debt ──────────────────────────────────────
                    SleepDebtCard(
                        progress: store.sleepDebtProgress,
                        deltaText: store.sleepDebtLabel
                    )

                    // ── Week Insight ────────────────────────────────────
                    WeekInsightCard(hours: store.weeklySleepHours)

                    // ── Sleep Phases ────────────────────────────────────
                    SleepPhaseBar(night: store.lastNight)

                    // ── Sleep Quality ───────────────────────────────────
                    SleepQualityCard(score: store.weeklySleepQuality)

                    // ── Sleep Stats ─────────────────────────────────────
                    sleepStatsSection

                    // ── Circadian Rhythm ────────────────────────────────
                    rhythmCard

                    // ── Tip Banner ──────────────────────────────────────
                    tipBanner
                }
                .padding(.horizontal, 18)
                .padding(.bottom, 32)
            }
            .background(AppTheme.background.ignoresSafeArea())
            .navigationTitle("Sleep Overview")
            .navigationBarTitleDisplayMode(.large)
        }
        .preferredColorScheme(.dark)
        .tint(AppTheme.accent)
    }

    // MARK: – Sleep stats (moved from ProfileView)

    private var sleepStatsSection: some View {
        VStack(alignment: .leading, spacing: 12) {
            Label("Sleep overview", systemImage: "moon.stars.fill")
                .font(.system(size: 16, weight: .bold, design: .rounded))
                .foregroundStyle(AppTheme.accentSoft)

            HStack(spacing: 10) {
                statTile(label: "Sleep debt",
                         value: store.sleepDebtLabel,
                         icon: "battery.25",
                         color: AppTheme.accent)
                statTile(label: "Avg / night",
                         value: avgNightLabel,
                         icon: "clock.fill",
                         color: AppTheme.purpleLight)
                statTile(label: "Quality",
                         value: qualityLabel,
                         icon: "star.fill",
                         color: AppTheme.accentSoft)
            }

            WeeklyBarsView(hours: store.weeklySleepHours)
                .frame(height: 70)
                .padding(.top, 4)
        }
        .appCard()
    }

    private func statTile(label: String, value: String,
                          icon: String, color: Color) -> some View {
        VStack(spacing: 6) {
            Image(systemName: icon)
                .font(.system(size: 18, weight: .semibold))
                .foregroundStyle(color)
            Text(value)
                .font(.system(size: 17, weight: .bold, design: .rounded))
                .foregroundStyle(.white)
            Text(label)
                .font(.system(size: 11))
                .foregroundStyle(.white.opacity(0.55))
                .multilineTextAlignment(.center)
        }
        .frame(maxWidth: .infinity)
        .padding(.vertical, 12)
        .background(
            RoundedRectangle(cornerRadius: 14, style: .continuous)
                .fill(AppTheme.cardElevated)
        )
    }

    private var avgNightLabel: String {
        let avg = store.weeklySleepHours.reduce(0, +) / Double(max(1, store.weeklySleepHours.count))
        return String(format: "%.1fh", avg)
    }

    private var qualityLabel: String {
        "\(Int(store.weeklySleepQuality * 100))%"
    }

    // MARK: – Circadian rhythm card

    private var rhythmCard: some View {
        VStack(alignment: .leading, spacing: 12) {
            Label("Circadian rhythm", systemImage: "moon.stars.fill")
                .font(.system(size: 17, weight: .bold, design: .rounded))
                .foregroundStyle(.white)

            HStack(spacing: 10) {
                rhythmStat(
                    label: "Bedtime",
                    value: store.tonightsPlan.map { df.string(from: $0.bedtime) } ?? "—",
                    color: AppTheme.accent,
                    symbol: "moon.fill"
                )
                rhythmStat(
                    label: "Wake up",
                    value: store.tonightsPlan.map { df.string(from: $0.wakeUp) } ?? "—",
                    color: AppTheme.orange,
                    symbol: "sun.max.fill"
                )
                rhythmStat(
                    label: "Duration",
                    value: store.tonightsPlan?.durationLabel ?? "—",
                    color: AppTheme.mint,
                    symbol: "clock.fill"
                )
            }
        }
        .appCard()
    }

    private func rhythmStat(label: String, value: String,
                             color: Color, symbol: String) -> some View {
        VStack(spacing: 6) {
            Image(systemName: symbol)
                .font(.system(size: 18, weight: .semibold))
                .foregroundStyle(color)
            Text(value)
                .font(.system(size: 16, weight: .bold, design: .rounded))
                .foregroundStyle(.white)
            Text(label)
                .font(.system(size: 11))
                .foregroundStyle(.white.opacity(0.55))
                .multilineTextAlignment(.center)
        }
        .frame(maxWidth: .infinity)
        .padding(.vertical, 12)
        .background(
            RoundedRectangle(cornerRadius: 14, style: .continuous)
                .fill(AppTheme.cardElevated)
        )
    }

    // MARK: – Tip banner

    private var tipBanner: some View {
        HStack(alignment: .top, spacing: 10) {
            Image(systemName: "lightbulb.fill")
                .foregroundStyle(AppTheme.yellow)
                .font(.system(size: 13))
                .padding(.top, 1)
            Text("These figures combine your saved sleep plans and Apple Health data. Keep adding shifts so RestOwl can learn your rhythm.")
                .font(.system(size: 12))
                .foregroundStyle(.white.opacity(0.60))
                .fixedSize(horizontal: false, vertical: true)
        }
        .padding(14)
        .background(
            RoundedRectangle(cornerRadius: 16, style: .continuous)
                .fill(AppTheme.card)
        )
    }
}

// MARK: – Weekly bar chart

private struct WeeklyBarsView: View {
    let hours: [Double]
    private let target = 8.0
    private let days   = ["M", "T", "W", "T", "F", "S", "S"]

    var body: some View {
        HStack(alignment: .bottom, spacing: 6) {
            ForEach(0..<min(hours.count, 7), id: \.self) { i in
                VStack(spacing: 4) {
                    RoundedRectangle(cornerRadius: 5, style: .continuous)
                        .fill(barColor(for: hours[i]))
                        .frame(height: barHeight(for: hours[i]))
                    Text(days[i])
                        .font(.system(size: 10, weight: .medium))
                        .foregroundStyle(.white.opacity(0.45))
                }
                .frame(maxWidth: .infinity)
            }
        }
        .frame(maxWidth: .infinity)
    }

    private func barHeight(for h: Double) -> CGFloat {
        CGFloat(min(h / target, 1.0)) * 52 + 4
    }

    private func barColor(for h: Double) -> Color {
        if h >= 7.0 { return AppTheme.accent }
        if h >= 5.5 { return AppTheme.purpleMid }
        return AppTheme.purpleDim
    }
}

#Preview {
    StateView()
        .environmentObject(HealthKitManager.shared)
        .environmentObject(AppStore())
        .preferredColorScheme(.dark)
}
