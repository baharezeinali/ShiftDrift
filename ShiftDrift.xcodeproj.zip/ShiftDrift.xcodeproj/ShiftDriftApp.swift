import SwiftUI

@main
struct ShiftDriftApp: App {
    @StateObject private var store = AppStore()
    @StateObject private var hk = HealthKitManager()

    var body: some Scene {
        WindowGroup {
            ContentView()
                .environmentObject(store)
                .environmentObject(hk)
        }
    }
}
