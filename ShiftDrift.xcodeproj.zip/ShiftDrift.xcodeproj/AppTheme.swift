//
//  AppTheme.swift
//  ShiftDrift
//
//  Design system — colours, card style, and spacing.
//  Palette is derived from the Wave Hands app icon:
//
//    Background  #0C1824  deep ocean night
//    Card        #152432  lifted surface
//    Accent      #5DCAA5  teal (the wave-hand colour)
//    Secondary   #4A90A8  cool steel blue
//    Warm        #F0A050  amber / sun
//    Mint        #A8EDD4  light mint highlight
//    Yellow      #F5D070  star / tip yellow
//

import SwiftUI

// MARK: - Colour tokens

enum AppTheme {

    // ── Backgrounds ──────────────────────────────────────────────────────────

    /// Deep ocean night — main screen background
    static let background   = Color(hex: "#0C1824")

    /// Lifted card surface
    static let card         = Color(hex: "#152432")

    /// Elevated card (modal, sheet, selected state)
    static let cardElevated = Color(hex: "#1E3044")

    // ── Accent (primary interactive) ─────────────────────────────────────────

    /// Wave-hands teal — primary buttons, highlights, active states
    static let accent       = Color(hex: "#5DCAA5")

    /// Softer teal — secondary labels, subdued icons
    static let accentSoft   = Color(hex: "#3AA87E")

    // ── Secondary (cool blue — replaces purple) ───────────────────────────────

    /// Steel blue — avg/night labels, secondary data
    static let blueLight    = Color(hex: "#6BAED4")

    /// Medium steel blue — bar chart mid values
    static let blueMid      = Color(hex: "#4A8AB4")

    /// Dim blue — bar chart low / background accents
    static let blueDim      = Color(hex: "#2A5A7A")

    // ── Semantic warm ────────────────────────────────────────────────────────

    /// Amber — sun, wake-up time, circadian day indicator
    static let orange       = Color(hex: "#F0A050")

    /// Light mint — quality score ring highlight
    static let mint         = Color(hex: "#A8EDD4")

    /// Star yellow — tip banner icon, rating star
    static let yellow       = Color(hex: "#F5D070")

    // ── Clock ring ───────────────────────────────────────────────────────────

    /// Muted teal — decorative ring strokes (matches icon ring)
    static let ringMuted    = Color(hex: "#2A5050")
}

// MARK: - SwiftUI view modifiers

struct AppCardModifier: ViewModifier {
    func body(content: Content) -> some View {
        content
            .padding(16)
            .background(
                RoundedRectangle(cornerRadius: 18, style: .continuous)
                    .fill(AppTheme.card)
            )
    }
}

extension View {
    func appCard() -> some View {
        modifier(AppCardModifier())
    }
}

// MARK: - Colour(hex:) initialiser

extension Color {
    init(hex: String) {
        let hex = hex.trimmingCharacters(in: CharacterSet.alphanumerics.inverted)
        var int: UInt64 = 0
        Scanner(string: hex).scanHexInt64(&int)
        let a, r, g, b: UInt64
        switch hex.count {
        case 3:
            (a, r, g, b) = (255,
                            (int >> 8) * 17,
                            (int >> 4 & 0xF) * 17,
                            (int & 0xF) * 17)
        case 6:
            (a, r, g, b) = (255,
                            int >> 16,
                            int >> 8 & 0xFF,
                            int & 0xFF)
        case 8:
            (a, r, g, b) = (int >> 24,
                            int >> 16 & 0xFF,
                            int >> 8  & 0xFF,
                            int       & 0xFF)
        default:
            (a, r, g, b) = (255, 0, 0, 0)
        }
        self.init(
            .sRGB,
            red:     Double(r) / 255,
            green:   Double(g) / 255,
            blue:    Double(b) / 255,
            opacity: Double(a) / 255
        )
    }
}

// MARK: - Migration map  (old token → new token)
//
//  Search & replace these in your Swift files when adopting ShiftDrift palette:
//
//  AppTheme.purpleLight  →  AppTheme.blueLight
//  AppTheme.purpleMid    →  AppTheme.blueMid
//  AppTheme.purpleDim    →  AppTheme.blueDim
//
//  Everything else keeps the same token name; only the hex values change.
